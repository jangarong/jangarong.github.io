import Homepage from "./homepage"

export default function Home() {
    return (
        <div>
            <Homepage />
        </div>
    )
}
