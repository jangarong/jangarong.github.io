const Colors = {
    1: "#FF8A00",
    2: "#FBFBFB",
    3: "#000000",
    4: "#00455A",
    5: "#F6F6F6",
    textLight: "#F6F6F6",
    textDark: "#000000"
}
export default Colors
