const args = [
    60000,
    [],
    [],
  ];

  export default args;