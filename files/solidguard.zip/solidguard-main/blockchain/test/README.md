<div align="center">
  <p align="center">
    <img src="../../api/docs/img/solidguard-prototype-v1-2.png" width="200" alt="SolidGuard Logo"/>
  </p>
<h1>SolidGuard Tests</h1>
</div>

## Running in Docker
```bash
docker build --file Dockerfile --tag solidguard-blockchain-test ..
docker run solidguard-blockchain-test
```
## Running locally
```bash
npm test
```
