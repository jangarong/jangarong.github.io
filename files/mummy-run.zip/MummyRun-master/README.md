Thank you all for working on this project, and for all those who have helped me!

Credits:
Main Coder - Jan
Main Setup - Stewart
Main Photoshopper - Toby

Main Game Artwork - Adam, Pato, Adara and Toby
Boss Rush Artwork - Jan, Emily

Joystick AS Code: 
http://johnstejskal.com/wp/virtual-joystick-for-mobile-games-using-as3/